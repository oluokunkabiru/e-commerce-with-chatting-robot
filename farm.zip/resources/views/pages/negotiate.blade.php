<html>
<head>
    <title>Negotiate</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/assets/css/chat.min.css">
</head>
<body>
<script id="botmanWidget" src='https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/js/chat.js'></script>
<script>
    var avatar = "{{ asset('asset/images/1597916009b.jpg') }}"
    var botmanWidget = {
        // chatServer : "/botman"
        title : "Negotiate this product",
        timeFormat : "HH:MM",
        dateTimeFormat : "d/m/yy HH:MM",
        introMessage : "Hi dear, you try to negotiate this product",
        mainColor : "#7fad39",
        bubbleBackground : "#7fad39",
        bubbleAvatarUrl :avatar,
        aboutText : "OLUOKUN KABIRU ADESINA"
    };
//     var botmanWidget = {
//   aboutText: 'Write Something',
//   introMessage: "✋ Hi! I'm Okediya Kenny <br><br> How may I help you?"
//   };
    </script>
    <script src='https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/js/widget.js'></script>

</body>
</html>
