@include('modals.header')

@yield('content')

@include('modals.footer')
