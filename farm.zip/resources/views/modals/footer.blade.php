</div>
    <div class="modal-footer">
        @yield('footer')
    </div>
    </div>
    </div>
</div>
