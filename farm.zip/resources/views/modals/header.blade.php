<div class="modal-dialog modal-lg">
    <div class="modal-content">
    <div class="modal-header">
    <h2 class="modal-title">@yield('title')</h2>
        <button type="button" class="btn btn-danger" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">Close</span>
        </button>
</div>
<div class="modal-body">
